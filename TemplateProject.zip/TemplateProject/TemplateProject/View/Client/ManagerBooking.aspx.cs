﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Client.Code.Entities;
using TemplateProject.View.Client.Code.Model;

namespace TemplateProject.View.Client
{
    public partial class ManagerBooking : System.Web.UI.Page
    {
        List<Bookings> list = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            LoadPage();

        }
        private void LoadPage()
        {
            string email = (string)Session["email"];
            Passenger p = PassengerModel.SearchPassenger(email);
            lbEmail.Text = email;
            lbName.Text = p.lastName + " " + p.firstName;
            lbPhone.Text = p.phoneNumber.ToString();
            lbArress.Text = p.address;
            list = Session["list"] as List<Bookings>;
            dataBooking.DataSource = list;
            dataBooking.DataBind();

        }
        protected void dataBooking_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int temp = e.RowIndex;
            string code = dataBooking.Rows[temp].Cells[0].Text.ToString();
            bool check = BookingModel.DeleteBooking(code);
            if (check == true)
            {
                Response.Redirect("Controller.aspx?action=searchManagerBooking");
            }


        }
        protected void dataBooking_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string temp = e.CommandName;
            if (temp.Equals("Select"))
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string code = dataBooking.Rows[index].Cells[0].Text.ToString();
                Response.Redirect("Controller.aspx?action=detailBooking&code=" + code);
            }
            else if (temp.Equals("Edit"))
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string code = dataBooking.Rows[index].Cells[0].Text.ToString();
                string planeID = dataBooking.Rows[index].Cells[1].Text.ToString();
                string fromCity = dataBooking.Rows[index].Cells[2].Text.ToString();
                string toCity = dataBooking.Rows[index].Cells[3].Text.ToString();
                string departDate = dataBooking.Rows[index].Cells[5].Text.ToString();
                Response.Redirect("Controller.aspx?action=editBooking&code=" + code + "&planeID=" + planeID + "&fromCity=" + fromCity + "&toCity=" + toCity + "&date=" + departDate);
            }
        }
        protected void dataBooking_PageIndexChanging1(object sender, GridViewPageEventArgs e)
        {
            LoadPage();
            dataBooking.PageIndex = e.NewPageIndex;
            dataBooking.DataBind();
        }
    }
}