﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Client.Code.Controller;
using TemplateProject.View.Client.Code.Entities;
using TemplateProject.View.Client.Code.Model;

namespace TemplateProject.View.Client
{
    public partial class Controller : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string action = Request.QueryString["action"];
            //========================================================= For login ================================================//
            if (action.Equals("login"))
            {
                string email = Request.QueryString["email"];
                string pass = Request.QueryString["pass"];
                bool check = false;
                List<Passenger> list = PassengerModel.GetPassenger();
                foreach (Passenger p in list)
                {
                    if (p.email.Equals(email))
                    {
                        if (p.password.Equals(pass))
                        {
                            check = true;
                        }
                    }
                }
                if (check == true)
                {
                    Session["email"] = email;
                    if (Session["booking"] == null)
                    {
                        Session["email"] = email;
                        Response.Redirect("Home.aspx");
                    }
                    else
                    {
                        string bookingDate = Manage.GetDate(true);
                        string bookingTime = Manage.GetTime();
                        Bookings b = Session["booking"] as Bookings;
                        Bookings b1 = Session["booking1"] as Bookings;
                        Session.Remove("booking");
                        Session.Remove("booking1");
                        List<Bookings> listSearch = null;
                        List<Bookings> listFormat = null;
                        if (b != null && b1 == null)
                        {
                            Bookings booking = new Bookings(email, b.planeID, bookingDate, bookingTime, b.reservationCode);
                            bool checkDepart = BookingModel.AddBooking(booking);

                            if (checkDepart == true)
                            {
                                listSearch = BookingModel.SearchBooking(b.reservationCode, "", true);
                                listFormat = FormatList.FormatListBooking(listSearch);
                                if (Session["list"] != null)
                                {
                                    Session.Remove("list");
                                }
                                Session["list"] = listFormat;
                                Response.Redirect("ManagerBooking.aspx");
                            }
                        }
                        else if (b != null && b1 != null)
                        {
                            Bookings booking = new Bookings(email, b.planeID, bookingDate, bookingTime, b.reservationCode);
                            bool checkDepart = BookingModel.AddBooking(booking);
                            Bookings booking1 = new Bookings(email, b1.planeID, bookingDate, bookingTime, b1.reservationCode);
                            bool checkReturn = BookingModel.AddBooking(b1);

                            if (checkDepart == true && checkReturn == true)
                            {
                                listSearch = BookingModel.SearchBooking(b.reservationCode, "", true);
                                listFormat = FormatList.FormatListBooking(listSearch);
                                if (Session["list"] != null)
                                {
                                    Session.Remove("list");
                                }
                                Session["list"] = listFormat;
                                Response.Redirect("ManagerBooking.aspx");
                            }
                        }
                    }
                }
                else
                {
                    string error = "Try Again ! Email ia password is not in DB";
                    Response.Redirect("Login.aspx?error=" + error);
                }
            }
            else if (action.Equals("seachBooking"))
            {
                string xReturn = "";
                string ticket = Request.QueryString["ticket"];
                string fromCity = Request.QueryString["fromCity"];
                string toCity = Request.QueryString["toCity"];
                string depart = Request.QueryString["depart"];
                if (ticket.Equals("roundtrip"))
                {
                    xReturn = Request.QueryString["xReturn"];
                    List<FlightPlane> listDepart = FlightModel.SearchFlight(depart, "", fromCity, toCity, true);
                    List<FlightPlane> listReturn = FlightModel.SearchFlight("", xReturn, fromCity, toCity, false);
                    List<FlightPlane> listDepartFormat = FormatList.FormatListFlight(listDepart);
                    List<FlightPlane> listReturnFormat = FormatList.FormatListFlight(listReturn);
                    if (listDepart.Count == 0 || listReturn.Count == 0)
                    {
                        string error = "The flight you want to find is not available";
                        Response.Redirect("Home.aspx?error=" + error);
                    }
                    else
                    {
                        if (Session["listDepart"] != null && Session["listReturn"] != null)
                        {
                            Session.Remove("listDepart");
                            Session.Remove("listReturn");
                        }

                        Session["listDepart"] = listDepartFormat;
                        Session["listReturn"] = listReturnFormat;
                        Response.Redirect("Booking.aspx?type=1");
                    }
                }
                else
                {
                    List<FlightPlane> listDepart = FlightModel.SearchFlight(depart, "", fromCity, toCity, true);
                    List<FlightPlane> listDepartFormat = FormatList.FormatListFlight(listDepart);
                    if (listDepart.Count == 0)
                    {
                        string error = "The flight you want to find is not available";
                        Response.Redirect("Home.aspx?error=" + error);
                    }
                    else
                    {
                        if (Session["listDepart"] != null)
                        {
                            Session.Remove("listDepart");

                        }
                        Session["listDepart"] = listDepartFormat;

                        Response.Redirect("Booking.aspx?type=0");
                    }

                }
            }
            else if (action.Equals("addBooking"))
            {
                string revercationCode = Manage.RandomReservationCode();
                string bookingDate = Manage.GetDate(true);
                string bookingTime = Manage.GetTime();
                string planeID = Request.QueryString["planeID"];
                string planeIDReturn = Request.QueryString["planeReturnID"];

                if (planeIDReturn != null)
                {

                    if (Session["email"] == null)
                    {
                        Bookings b = new Bookings(planeID, revercationCode);
                        Bookings b1 = new Bookings(planeIDReturn, revercationCode);
                        if (Session["booking"] != null)
                        {
                            Session.Remove("booking");
                        }
                        if (Session["booking1"] != null)
                        {
                            Session.Remove("booking1");
                        }
                        Session["booking"] = b;
                        Session["booking1"] = b1;

                        Response.Redirect("Login.aspx");
                    }
                    else
                    {
                        string email = (string)Session["email"];

                        Bookings b = new Bookings(email, planeID, bookingDate, bookingTime, revercationCode);
                        bool check = BookingModel.AddBooking(b);

                        Bookings b1 = new Bookings(email, planeIDReturn, bookingDate, bookingTime, revercationCode);
                        bool checkReturn = BookingModel.AddBooking(b1);

                        if (check == true)
                        {
                            //  Passenger p = PassengerController.SearchPassenger(email);

                            List<Bookings> list = BookingModel.SearchBooking(revercationCode, "", true);
                            List<Bookings> listFormat = FormatList.FormatListBooking(list);
                            if (Session["list"] != null)
                            {
                                Session.Remove("list");
                            }
                            Session["list"] = listFormat;


                            Response.Redirect("ManagerBooking.aspx");
                        }
                        if (check == true && checkReturn == true)
                        {
                            Response.Redirect("ManagerBooking.aspx?code=" + revercationCode);
                        }
                    }
                }
                else
                {
                    if (Session["email"] == null)
                    {
                        Bookings b = new Bookings(planeID, revercationCode);
                        if (Session["booking"] != null)
                        {
                            Session.Remove("booking");
                        }
                        Session["booking"] = b;

                        Response.Redirect("Login.aspx");
                    }
                    else
                    {
                        string email = (string)Session["email"];

                        Bookings b = new Bookings(email, planeID, bookingDate, bookingTime, revercationCode);
                        bool check = BookingModel.AddBooking(b);

                        if (check == true)
                        {
                            //  Passenger p = PassengerController.SearchPassenger(email);

                            List<Bookings> list = BookingModel.SearchBooking(revercationCode, "", true);
                            List<Bookings> listFormat = FormatList.FormatListBooking(list);
                            if (Session["list"] != null)
                            {
                                Session.Remove("list");
                            }
                            Session["list"] = listFormat;


                            Response.Redirect("ManagerBooking.aspx");
                        }
                    }
                }
            }
            else if (action.Equals("register"))
            {
                bool checkDuplicateEmail = false;
                string email = Request.QueryString["email"];
                string password = Request.QueryString["password"];
                string firstName = Request.QueryString["firstName"];
                string lastName = Request.QueryString["lastName"];
                string address = Request.QueryString["address"];
                string sex = Request.QueryString["sex"];
                int phoneNumber = Convert.ToInt32(Request.QueryString["phoneNumber"]);
                int age = Convert.ToInt32(Request.QueryString["age"]);
                int cardNumber = Convert.ToInt32(Request.QueryString["cardNumber"]);
                Passenger p = new Passenger(email, password, firstName, lastName, address, sex, phoneNumber, age, cardNumber);
                p.Avatar = "Resources/images/PassengerAvatar/DefaultAvatar.png";
                List<Passenger> list = PassengerModel.GetPassenger();
                foreach (Passenger ps in list)
                {
                    if (ps.email.Equals(email))
                    {
                        checkDuplicateEmail = true;
                    }
                }

                if (checkDuplicateEmail == true)
                {
                    string error = "";
                    Response.Redirect("Register.aspx?error=" + error);
                }
                else
                {
                    bool check = PassengerModel.AddPassenger(p);
                    if (check == true)
                    {
                        Response.Redirect("Login.aspx");
                    }
                }
            }
            else if (action.Equals("searchManagerBooking"))
            {
                string code = Request.QueryString["code"];
                string email = (string)Session["email"];
                if (code != null)
                {
                    List<Bookings> list = BookingModel.SearchBooking(code, "", true);
                    List<Bookings> listFormat = FormatList.FormatListBooking(list);
                    if (Session["list"] != null)
                    {
                        Session.Remove("list");
                    }
                    Session["list"] = listFormat;
                    Response.Redirect("ManagerBooking.aspx");
                }
                else
                {
                    List<Bookings> list = BookingModel.SearchBooking("", email, false);
                    List<Bookings> listFormat = FormatList.FormatListBooking(list);
                    if (Session["list"] != null)
                    {
                        Session.Remove("list");
                    }
                    Session["list"] = listFormat;
                    Response.Redirect("ManagerBooking.aspx");
                }
            }
            else if (action.Equals("logOut"))
            {
                if (Session["email"] != null)
                {
                    Session.Remove("email");
                    Response.Redirect("Login.aspx");
                }

            }
            else if (action.Equals("manager"))
            {
                if (Session["email"] != null)
                {
                    Response.Redirect("SearchBooking.aspx");
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }
            else if (action.Equals("detailBooking"))
            {
                string code = Request.QueryString["code"];
                List<Bookings> listDetail = BookingModel.SearchBooking(code, "", true);
                if (Session["listDetail"] != null)
                {
                    Session.Remove("listDetail");
                }
                List<Bookings> listDetailFormat = FormatList.FormatListBooking(listDetail);
                Session["listDetail"] = listDetailFormat;
                Response.Redirect("DetailBooking.aspx");

            }
            else if (action.Equals("editBooking"))
            {
                string code = Request.QueryString["code"];
                string planeID = Request.QueryString["planeID"];
                string fromCity = Request.QueryString["fromCity"];
                string toCity = Request.QueryString["toCity"];
                string date = Request.QueryString["date"];
                string departDate = date.Replace("12:00:00 AM", "");
                List<FlightPlane> listEdit = FlightModel.SearchEditFlight(departDate, fromCity, toCity, planeID);

                string bookingID = BookingModel.searchBookingID(code, planeID);

                if (Session["bookingIDEdit"] != null)
                {
                    Session.Remove("bookingIDEdit");
                }
                if (Session["listEdit"] != null)
                {
                    Session.Remove("listEdit");
                }
                List<FlightPlane> listEditFormat = FormatList.FormatListFlight(listEdit);
                Session["bookingIDEdit"] = bookingID;
                Session["listEdit"] = listEditFormat;
                Response.Redirect("EditBooking.aspx");
            }
            else if (action.Equals("addEditBooking"))
            {
                string bookingDate = Manage.GetDate(true);
                string bookingTime = Manage.GetTime();
                string planeID = Request.QueryString["planeID"];
                //   string code = (string)Session["codeEdit"];
                string bookingID = (string)Session["bookingIDEdit"];
                bool check = BookingModel.EditBooking(bookingID, planeID, bookingDate, bookingTime);
                Response.Redirect("SearchBooking.aspx");
            }
            else if (action.Equals("detailPassenger"))
            {
                string email = Session["email"].ToString();
                Passenger p = PassengerModel.SearchPassenger(email);
                if (Session["detailPassenger"] != null)
                {
                    Session.Remove("detailPassenger");
                }
                Session["detailPassenger"] = p;
                Response.Redirect("DetailPassenger.aspx");
            }
            else if (action.Equals("editPassenger"))
            {
                string email = Session["email"].ToString();
                Passenger p = Session["PEdit"] as Passenger;

                bool check = PassengerModel.UpdatePassenger(email, p);
                if (check == true)
                {
                    Passenger pDetail = PassengerModel.SearchPassenger(email);
                    if (Session["detailPassenger"] != null)
                    {
                        Session.Remove("detailPassenger");
                    }
                    Session["detailPassenger"] = pDetail;
                    Response.Redirect("DetailPassenger.aspx");
                }
                else
                {
                }

            }
            else if (action.Equals("changePass"))
            {
                string email = Session["email"].ToString();
                string newPass = Request.QueryString["newPass"];
                bool check = PassengerModel.UpdatePass(email, newPass);
                if (check == true)
                {
                    Passenger pDetail = PassengerModel.SearchPassenger(email);
                    if (Session["detailPassenger"] != null)
                    {
                        Session.Remove("detailPassenger");
                    }
                    Session["detailPassenger"] = pDetail;
                    Response.Redirect("DetailPassenger.aspx");
                }
                else
                {
                }
            }
        }
    }
}