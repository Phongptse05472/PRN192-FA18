﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Client.Code.Entities;

namespace TemplateProject.View.Client
{
    public partial class EditBooking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                LoadPage();
            }
        }
        private void LoadPage()
        {
            List<FlightPlane> listEdit = Session["listEdit"] as List<FlightPlane>;
            string fromCity = "";
            string toCity = "";

            foreach (FlightPlane fp in listEdit)
            {
                fromCity = fp.fromCity;
                toCity = fp.toCity;
                break;
            }
            lbDepart.Text = fromCity + " to " + toCity;
            dataEditBooking.DataSource = listEdit;
            dataEditBooking.DataBind();
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string planeID = "";
            string code = "";
            foreach (GridViewRow row in dataEditBooking.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkRow = (row.Cells[5].FindControl("chkRow") as CheckBox);
                    if (chkRow.Checked)
                    {
                        planeID = row.Cells[0].Text;
                        code = row.Cells[0].Text;
                    }
                }
            }
            Response.Redirect("Controller.aspx?action=addEditBooking&planeID=" + planeID);
        }
    }
}