﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Client.Code.Entities;
using TemplateProject.View.Client.Code.Model;

namespace TemplateProject.View.Client
{
    public partial class DetailBooking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string email = (string)Session["email"];
            List<Bookings> detailBooking = Session["listDetail"] as List<Bookings>;
            Passenger p = PassengerModel.SearchPassenger(email);
            lbEmail.Text = email;
            lbName.Text = p.lastName + " " + p.firstName;
            lbPhone.Text = p.phoneNumber.ToString();
            lbArress.Text = p.address;
            foreach (Bookings b in detailBooking)
            {
                lbCode.Text = b.reservationCode;
                lbFlight.Text = b.flightID.ToString();
                lbPlane.Text = b.planeID;
                lbBookingDate.Text = b.bookingDate;
                lbBookingTime.Text = b.bookingTime;
                lbFCity.Text = b.fromCity;
                lbTCity.Text = b.toCity;
                lbDepartDate.Text = b.departureDate;
                lbDepartTime.Text = b.departureTime;
                lbArrival.Text = b.arrives;
                lbFareBasic.Text = b.fare.ToString();
            }
        }
    }
}