﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Client.Code.Entities;
using TemplateProject.View.Client.Code.Model;

namespace TemplateProject.View.Client
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPage();
            }
        }
        protected void btnSeach_Click(object sender, EventArgs e)
        {
            string ticket = "";
            string fromCity = dropFrom.SelectedValue.ToString();
            string toCity = dropTo.SelectedValue.ToString();
            string depart = txtDatePicker.Text;
            string xReturn = txtDatePicker0.Text; ;

            if (fromCity.Equals(toCity))
            {
                lbError.Visible = true;
                lbError.Text = "Please choose from City is different to City !";
            }
            else if (depart.Equals(""))
            {
                lbError.Visible = true;
                lbError.Text = "Please choose Departure !";
            }
            else
            {
                if (radioOneWay.Checked)
                {
                    ticket = "oneway";
                    Response.Redirect("Controller.aspx?action=seachBooking&fromCity=" + fromCity + "&toCity=" + toCity + "&depart=" + depart + "&ticket=" + ticket + "");
                }
                else if (radioRoundTrip.Checked)
                {
                    ticket = "roundtrip";
                    Response.Redirect("Controller.aspx?action=seachBooking&fromCity=" + fromCity + "&toCity=" + toCity + "&depart=" + depart + "&ticket=" + ticket + "&xReturn=" + xReturn + "");
                }
            }
        }

        private void LoadPage()
        {
            List<City> listC = CityModel.GetCity();
            foreach (City c in listC)
            {
                dropFrom.Items.Add(c.cityName);
                dropTo.Items.Add(c.cityName);
            }
            string error = Request.QueryString["error"];
            if (error != null)
            {
                lbError.Visible = true;
                lbError.Text = error;
            }
        }
    }
}