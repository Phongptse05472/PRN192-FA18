﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TemplateProject.View.Client
{
    public partial class SearchBooking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (radioCode.Checked)
            {
                string code = txtCode.Text;
                Response.Redirect("Controller.aspx?action=searchManagerBooking&code=" + code + "");
            }
            else if (radioAll.Checked)
            {
                Response.Redirect("Controller.aspx?action=searchManagerBooking");
            }
        }
    }
}