﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Client.Code.Entities;

namespace TemplateProject.View.Client
{
    public partial class Booking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                LoadPage();
            }
        }
        private void LoadPage()
        {
            string ticket = Request.QueryString["ticket"];
            string fromCity = "";
            string toCity = "";

            string type = Request.QueryString["type"];

            string error = Request.QueryString["error"];
            if (error != null)
            {
                lbMess.Text = error;
            }
            else
            {

                if (type.Equals("1"))
                {
                    List<FlightPlane> listDepart = Session["listDepart"] as List<FlightPlane>;
                    List<FlightPlane> listReturn = Session["listReturn"] as List<FlightPlane>;
                    foreach (FlightPlane fp in listDepart)
                    {
                        fromCity = fp.fromCity;
                        toCity = fp.toCity;
                        break;
                    }
                    lbMess.Text = "Select Your Flight";
                    lbDepart.Text = fromCity + " to " + toCity;
                    lbReturn.Text = toCity + " to " + fromCity;
                    dataDepart.DataSource = listDepart;
                    dataReturn.DataSource = listReturn;
                    dataDepart.DataBind();
                    dataReturn.DataBind();
                }
                else
                {
                    List<FlightPlane> listDepart = Session["listDepart"] as List<FlightPlane>;
                    foreach (FlightPlane fp in
                        listDepart)
                    {
                        fromCity = fp.fromCity;
                        toCity = fp.toCity;
                        break;
                    }
                    //   Session.Remove("listDepart");
                    lbMess.Text = "Select Your Flight";
                    lbDepart.Text = fromCity + " to " + toCity;
                    dataDepart.DataSource = listDepart;
                    dataDepart.DataBind();

                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string planeID = "";
            string planeIDReturn = "";
            foreach (GridViewRow row in dataDepart.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkRow = (row.Cells[6].FindControl("chkRow") as CheckBox); // ra false
                                                                                        //  CheckBox chkRow = (CheckBox)row.FindControl("chkRow");
                    if (chkRow.Checked)
                    {
                        planeID = row.Cells[0].Text;
                    }
                }
            }


            //if (dataReturn.DataSource != null)
            if (dataReturn != null)
            {
                foreach (GridViewRow row in dataReturn.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chkRow = (row.Cells[6].FindControl("chkRowReturn") as CheckBox);

                        if (chkRow.Checked)

                        {
                            planeIDReturn = row.Cells[0].Text;
                        }
                    }
                }

                if (planeID.Equals("") || planeIDReturn.Equals(""))
                {
                    lbError.Text = "Please chossen one flight !";
                }
                else
                {
                    Response.Redirect("Controller.aspx?action=addBooking&planeID=" + planeID + "&planeReturnID=" + planeIDReturn);
                }
            }
            else
            {
                if (planeID.Equals(""))
                {
                    lbError.Text = "Please chossen one flight !";
                }
                else
                {
                    Response.Redirect("Controller.aspx?action=addBooking&planeID=" + planeID);
                }
            }
        }

        protected void dataDepart_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            LoadPage();
            dataDepart.PageIndex = e.NewPageIndex;
            dataDepart.DataBind();
        }
    }
}