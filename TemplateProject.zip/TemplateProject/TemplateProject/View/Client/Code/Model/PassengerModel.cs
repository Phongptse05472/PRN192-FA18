﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; // connection
using System.Data; // datatable ,dataset
using System.Web.Configuration; // read connection string in web config
using TemplateProject.View.Client.Code.Entities;

namespace TemplateProject.View.Client.Code.Model
{
    public class PassengerModel
    {
        public string ConnectionString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString;

        public PassengerModel()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        public static bool AddPassenger(Passenger p)
        {
            int test = 0;
            try
            {
                DBContext.conn.Open();

                string query = "insert into Passengers values (@Email,@Password,@FirstName,@LastName,@Address,@PhoneNumber,@Sex,@Age,@CardNumber)";
                SqlCommand sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("Email", p.email);
                sc.Parameters.AddWithValue("Password", p.password);
                sc.Parameters.AddWithValue("FirstName", p.firstName);
                sc.Parameters.AddWithValue("LastName", p.lastName);
                sc.Parameters.AddWithValue("Address", p.address);
                sc.Parameters.AddWithValue("PhoneNumber", p.phoneNumber);
                sc.Parameters.AddWithValue("Sex", p.sex);
                sc.Parameters.AddWithValue("Age", p.age);
                sc.Parameters.AddWithValue("CardNumber", p.cardNumber);
                test = sc.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }
            if (test <= 0)
            {
                return false;
            }
            return true;
        }

        public static List<Passenger> GetPassenger()
        {

            string query = "select * from Passengers";

            List<Passenger> list = new List<Passenger>();
            DataTable data = new DataTable();
            try
            {
                DBContext.conn.Open();
                SqlCommand sc = new SqlCommand(query, DBContext.conn);

                SqlDataAdapter adapter = new SqlDataAdapter(sc);

                adapter.Fill(data);



                foreach (DataRow item in data.Rows)
                {

                    string email = item["Email"].ToString();
                    string password = item["Password"].ToString();
                    string firstName = item["FirstName"].ToString();
                    string lastName = item["LastName"].ToString();
                    string address = item["Address"].ToString();
                    int phoneNumber = Convert.ToInt32(item["PhoneNumber"].ToString());
                    string sex = item["Sex"].ToString();
                    int age = Convert.ToInt16(item["Age"].ToString());
                    int cardNumber = Convert.ToInt32(item["CardNumber"].ToString());

                    Passenger p = new Passenger(email, password, firstName, lastName, address, sex, phoneNumber, age, cardNumber);
                    list.Add(p);

                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }

            return list;

        }
        public static Passenger SearchPassenger(string xEmail)
        {


            Passenger p = null;
            SqlCommand sc = null;
            DataTable data = new DataTable();
            try
            {
                DBContext.conn.Open();

                string query = "select * from Passengers where email=@xEmail";

                sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("xEmail", xEmail);

                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                adapter.Fill(data);

                foreach (DataRow item in data.Rows)
                {

                    string email = item["Email"].ToString();
                    string password = item["Password"].ToString();
                    string firstName = item["FirstName"].ToString();
                    string lastName = item["LastName"].ToString();
                    string address = item["Address"].ToString();
                    int phoneNumber = Convert.ToInt32(item["PhoneNumber"].ToString());
                    string sex = item["Sex"].ToString();
                    int age = Convert.ToInt16(item["Age"].ToString());
                    int cardNumber = Convert.ToInt32(item["CardNumber"].ToString());

                    p = new Passenger(email, password, firstName, lastName, address, sex, phoneNumber, age, cardNumber);


                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }

            return p;

        }

        public static bool UpdatePassenger(string xEmail, Passenger p)
        {



            DBContext.conn.Open();
            string query = "";
            SqlCommand sc = null;
            try
            {
                query = " UPDATE Passengers SET FirstName=@fistName , LastName=@lastName , Address=@address ,PhoneNumber=@phone ,Sex=@sex ,Age=@age ,CardNumber=@card  WHERE   Email =@email  ";

                sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("@fistName", p.firstName);
                sc.Parameters.AddWithValue("@lastName", p.lastName);
                sc.Parameters.AddWithValue("@address", p.address);
                sc.Parameters.AddWithValue("@phone", p.phoneNumber);
                sc.Parameters.AddWithValue("@sex", p.sex);
                sc.Parameters.AddWithValue("@age", p.age);
                sc.Parameters.AddWithValue("@card ", p.cardNumber);
                sc.Parameters.AddWithValue("@email", xEmail);


                sc.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
                return false;
            }
            finally
            {
                DBContext.conn.Close();
            }

            return true;
        }

        public static bool UpdatePass(string xEmail, string newPass)
        {



            DBContext.conn.Open();
            string query = "";
            SqlCommand sc = null;
            try
            {
                query = " UPDATE Passengers SET Password=@newPass  WHERE   Email =@email  ";

                sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("@newPass", newPass);
                sc.Parameters.AddWithValue("@email", xEmail);
                sc.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
                return false;
            }
            finally
            {
                DBContext.conn.Close();
            }

            return true;
        }
        //===================================================//
        public Passenger getPassengerByEmail(string email)
        {
            string query = "select * from Passengers where Email=@email";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@email", email);
            SqlDataReader dr = cmd.ExecuteReader();
            Passenger passenger = new Passenger();
            if (dr.Read())
            {
                passenger.email = SafeGetString(dr, "Email");
                passenger.password = SafeGetString(dr, "Password");
                passenger.firstName = SafeGetString(dr, "FirstName");
                passenger.lastName = SafeGetString(dr, "LastName");
                passenger.address = SafeGetString(dr, "Address");
                passenger.phoneNumber = SafeGetInt(dr, "PhoneNumber");
                passenger.sex = (SafeGetBool(dr, "Sex") == true) ? "Male" : "Female";
                passenger.age = SafeGetInt(dr, "Age");
                passenger.cardNumber = SafeGetInt(dr, "CardNumber");
                passenger.Facebook = SafeGetString(dr, "Facebook");
                passenger.Avatar = SafeGetString(dr, "Avatar");
                passenger.BirthDate = SafeGetDatetime(dr, "Birthdate");
                conn.Close();
                return passenger;
            }
            conn.Close();
            return null;
        }
        private string SafeGetString(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetString(dr.GetOrdinal(colName));
            }
            return null;
        }
        private int SafeGetInt(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetInt32(dr.GetOrdinal(colName));
            }
            return 0;
        }
        private bool SafeGetBool(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetBoolean(dr.GetOrdinal(colName));
            }
            return false;
        }
        private string SafeGetDatetime(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetDateTime(dr.GetOrdinal(colName)).ToString("yyyy-MM-dd");
            }
            return null;
        }
    }
}