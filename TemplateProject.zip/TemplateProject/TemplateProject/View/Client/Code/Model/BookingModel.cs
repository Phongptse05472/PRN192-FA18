﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; // connection
using System.Data; // datatable ,dataset
using TemplateProject.View.Client.Code.Entities;

namespace TemplateProject.View.Client.Code.Model
{
    public class BookingModel
    {
        public BookingModel()
        {
        }

        public static bool AddBooking(Bookings b)
        {
            int test = 0;
            try
            {
                DBContext.conn.Open();

                string query = "insert into Bookings values(@Email,@PlaneID,@BookingDate,@BookingTime,@ReservationCode)";
                SqlCommand sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("Email", b.email);
                sc.Parameters.AddWithValue("PlaneID", b.planeID);
                sc.Parameters.AddWithValue("BookingDate", b.bookingDate);
                sc.Parameters.AddWithValue("BookingTime", b.bookingTime);
                sc.Parameters.AddWithValue("ReservationCode", b.reservationCode);

                test = sc.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }
            if (test <= 0)
            {
                return false;
            }
            return true;

        }

        public static List<Bookings> SearchBooking(string code, string xEmail, bool condition)
        {


            List<Bookings> list = new List<Bookings>();
            DataTable data = new DataTable();
            DBContext.conn.Open();
            string query = "";
            SqlCommand sc = null;
            try
            {
                if (condition == true)
                {
                    query = " select b.ReservationCode,b.Email,b.PlaneID,b.BookingDate,b.BookingTime,pg.FirstName,pg.LastName,p.FlightID,p.Fare,p.DepartureDate,p.DepartureTime,f.FromCity,f.ToCity,f.Duration "
                            + " from Flight f,Plane p ,Bookings b,Passengers pg "
                            + " where  p.FlightID=f.FlightID and p.PlaneID = b.PlaneID and b.Email=pg.Email and b.ReservationCode = @code ";
                    sc = new SqlCommand(query, DBContext.conn);
                    sc.Parameters.AddWithValue("code", code);

                }
                else
                {
                    query = " select b.ReservationCode,b.Email,b.PlaneID,b.BookingDate,b.BookingTime,pg.FirstName,pg.LastName,p.FlightID,p.Fare,p.DepartureDate,p.DepartureTime,f.FromCity,f.ToCity,f.Duration "
                             + " from Flight f,Plane p ,Bookings b,Passengers pg "
                             + " where  p.FlightID=f.FlightID and p.PlaneID = b.PlaneID and b.Email=pg.Email and b.Email = @xEmail ";

                    sc = new SqlCommand(query, DBContext.conn);
                    sc.Parameters.AddWithValue("xEmail", xEmail);

                }



                SqlDataAdapter adapter = new SqlDataAdapter(sc);

                adapter.Fill(data);

                foreach (DataRow item in data.Rows)
                {
                    string reservationCode = item["ReservationCode"].ToString();
                    string email = item["Email"].ToString();
                    string planeID = item["PlaneID"].ToString();
                    string xBookingDate = item["BookingDate"].ToString();
                    string xBookingTime = item["BookingTime"].ToString();
                    string bookingDate = xBookingDate.Replace("12:00:00 AM", "");
                    string bookingTime = xBookingTime.Replace("12:00:00 AM", "");
                    string firstName = item["FirstName"].ToString();
                    string lastName = item["LastName"].ToString();
                    int flightID = Convert.ToInt16(item["FlightID"].ToString());
                    float fare = float.Parse(item["Fare"].ToString());
                    string xDepartureDate = item["DepartureDate"].ToString();
                    string xDepartureTime = item["DepartureTime"].ToString();
                    string departureTime = xDepartureTime.Replace("12:00:00 AM", "");
                    string departureDate = xDepartureDate.Replace("12:00:00 AM", "");
                    string fromCity = item["FromCity"].ToString();
                    string toCity = item["ToCity"].ToString();
                    float duration = float.Parse(item["Duration"].ToString());

                    Bookings b = new Bookings(reservationCode, email, planeID, bookingDate, bookingTime, firstName, lastName, flightID, fare, departureDate, departureTime, fromCity, toCity, duration);
                    list.Add(b);
                }


            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }

            return list;
        }


        public static bool DeleteBooking(string code)
        {


            List<Bookings> list = new List<Bookings>();
            DataTable data = new DataTable();
            DBContext.conn.Open();
            string query = "";
            SqlCommand sc = null;
            try
            {


                query = " DELETE FROM Bookings WHERE ReservationCode = @code ";

                sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("code", code);

                sc.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
                return false;
            }
            finally
            {
                DBContext.conn.Close();
            }

            return true;
        }

        public static string searchBookingID(string code, string planeID)
        {
            DataTable data = new DataTable();
            DBContext.conn.Open();
            string query = "";
            string BookingID = "";
            SqlCommand sc = null;
            try
            {


                query = " select  BookingID from Bookings where ReservationCode = @code and PlaneID = @planeID ";

                sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("@code", code);
                sc.Parameters.AddWithValue("@planeID", planeID);


                SqlDataAdapter adapter = new SqlDataAdapter(sc);

                adapter.Fill(data);

                foreach (DataRow item in data.Rows)
                {
                    BookingID = item["BookingID"].ToString();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());

            }
            finally
            {
                DBContext.conn.Close();
            }

            return BookingID;
        }

        public static bool EditBooking(string bookingID, string xPlaneID, string xBookingDate, string xBookingTime)
        {

            DBContext.conn.Open();
            string query = "";
            SqlCommand sc = null;
            try
            {
                query = " UPDATE Bookings SET PlaneID = @planeID , BookingDate = @bookingDate , BookingTime = @bookingTime  WHERE   BookingID = @bookingID ";

                sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("@planeID", xPlaneID);
                sc.Parameters.AddWithValue("@bookingDate", xBookingDate);
                sc.Parameters.AddWithValue("@bookingTime", xBookingTime);
                sc.Parameters.AddWithValue("@bookingID", bookingID);

                sc.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
                return false;
            }
            finally
            {
                DBContext.conn.Close();
            }

            return true;
        }

    }
}