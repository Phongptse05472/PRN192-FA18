﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using TemplateProject.View.Client.Code.Entities;

namespace TemplateProject.View.Client.Code.Model
{
    public class CityModel
    {
        public CityModel()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public static List<City> GetCity()
        {
            string query = "select * from Cities";

            List<City> list = new List<City>();
            DataTable data = new DataTable();
            try
            {

                DBContext.conn.Open();
                SqlCommand sc = new SqlCommand(query, DBContext.conn);

                SqlDataAdapter adapter = new SqlDataAdapter(sc);

                adapter.Fill(data);

                foreach (DataRow item in data.Rows)
                {

                    int cityID = Convert.ToInt16(item["CityID"].ToString());
                    string cityName = item["CityName"].ToString();
                    City c = new City(cityID, cityName);
                    list.Add(c);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }

            return list;

        }
    }
}