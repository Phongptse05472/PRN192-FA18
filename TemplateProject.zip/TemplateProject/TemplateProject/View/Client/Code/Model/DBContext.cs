﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; // connection
using System.Web.Configuration; // read connection string in web config

namespace TemplateProject.View.Client.Code.Model
{
    public class DBContext
    {
        public static string connString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString.ToString();
        public static SqlConnection conn = new SqlConnection(connString);
    }
}