﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration; // read connection string in web config
using System.Data.SqlClient; // connection
using System.Data; // datatable ,dataset
using TemplateProject.View.Client.Code.Entities;

namespace TemplateProject.View.Client.Code.Model
{
    public class FlightModel
    {
        public FlightModel()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        public static List<FlightPlane> SearchFlight(string departDate, string returnDate, string xFromCity, string xToCity, bool condition)
        {

            List<FlightPlane> list = new List<FlightPlane>();
            DataTable data = new DataTable();
            try
            {
                DBContext.conn.Open();
                string query = "";
                SqlCommand sc = null;
                if (condition == true)
                {
                    query = "select f.FlightID,f.FromCity,f.ToCity,f.Duration,p.PlaneID,p.DepartureDate,p.DepartureTime,p.Fare "
                             + " from Flight f,Plane p "
                             + " where  p.FlightID=f.FlightID and p.DepartureDate = @departDate and f.FromCity =  @xFromCity   and f.ToCity =  @xToCity  ";
                    //  query = @" select * from Flight f,Plane p where  p.FlightID=f.FlightID and p.DepartureDate = '2017-05-01' and f.FromCity = 'Ha Noi' and f.ToCity =  'Hue' ";
                    sc = new SqlCommand(query, DBContext.conn);
                    sc.Parameters.AddWithValue("departDate", departDate);
                    sc.Parameters.AddWithValue("xFromCity", xFromCity);
                    sc.Parameters.AddWithValue("xToCity", xToCity);
                }
                else
                {
                    query = "select f.FlightID,f.FromCity,f.ToCity,f.Duration,p.PlaneID,p.DepartureDate,p.DepartureTime,p.Fare "
                        + " from Flight f,Plane p "
                        + " where  p.FlightID=f.FlightID and p.DepartureDate = @departDate and f.FromCity = @xFromCity and f.ToCity =  @xToCity ";

                    sc = new SqlCommand(query, DBContext.conn);
                    sc.Parameters.AddWithValue("departDate", returnDate);
                    sc.Parameters.AddWithValue("xFromCity", xToCity);
                    sc.Parameters.AddWithValue("xToCity", xFromCity);
                }



                //SqlDataAdapter adapter = new SqlDataAdapter(query, DBContext.conn);

                SqlDataAdapter adapter = new SqlDataAdapter(sc);

                adapter.Fill(data);

                foreach (DataRow item in data.Rows)
                {
                    int flightID = Convert.ToInt16(item["FlightID"].ToString());
                    string fromCity = item["FromCity"].ToString();
                    string toCity = item["ToCity"].ToString();
                    float duration = float.Parse(item["Duration"].ToString());
                    string planeID = item["PlaneID"].ToString();
                    float fare = float.Parse(item["Fare"].ToString());
                    string xDepartureTime = item["DepartureTime"].ToString();
                    string xDepartureDate = item["DepartureDate"].ToString();
                    string departureTime = xDepartureTime.Replace("12:00:00 AM", "");
                    string departureDate = xDepartureDate.Replace("12:00:00 AM", "");
                    string arrives = "";

                    FlightPlane fp = new FlightPlane(flightID, fromCity, toCity, duration, planeID, fare, departureTime, departureDate, arrives);

                    list.Add(fp);

                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }

            return list;
        }


        public static FlightPlane SearchPlane(string xPlaneID)
        {

            FlightPlane fp = null;
            DataTable data = new DataTable();
            try
            {
                DBContext.conn.Open();
                string query = "";
                SqlCommand sc = null;

                query = "select f.FlightID,f.FromCity,f.ToCity,f.Duration,p.PlaneID,p.DepartureDate,p.DepartureTime,p.Fare "
                    + " from Flight f,Plane p "
                     + " where p.FlightID = f.FlightID and p.PlaneID = @ID  ";

                sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("ID", xPlaneID);





                //SqlDataAdapter adapter = new SqlDataAdapter(query, DBContext.conn);

                SqlDataAdapter adapter = new SqlDataAdapter(sc);

                adapter.Fill(data);

                foreach (DataRow item in data.Rows)
                {
                    int flightID = Convert.ToInt16(item["FlightID"].ToString());
                    string fromCity = item["FromCity"].ToString();
                    string toCity = item["ToCity"].ToString();
                    float duration = float.Parse(item["Duration"].ToString());
                    string planeID = item["PlaneID"].ToString();
                    float fare = float.Parse(item["Fare"].ToString());
                    string xDepartureTime = item["DepartureTime"].ToString();
                    string xDepartureDate = item["DepartureDate"].ToString();
                    string departureTime = xDepartureTime.Replace("12:00:00 AM", "");
                    string departureDate = xDepartureDate.Replace("12:00:00 AM", "");
                    string arrives = "";

                    fp = new FlightPlane(flightID, fromCity, toCity, duration, planeID, fare, departureTime, departureDate, arrives);



                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }

            return fp;
        }

        public static List<FlightPlane> SearchEditFlight(string date, string xFromCity, string xToCity, string xPlaneID)
        {
            List<FlightPlane> list = new List<FlightPlane>();

            DataTable data = new DataTable();
            try
            {
                DBContext.conn.Open();
                string query = "";
                SqlCommand sc = null;

                query = " select f.FlightID,f.FromCity,f.ToCity,f.Duration,p.PlaneID,p.DepartureDate,p.DepartureTime,p.Fare "
                      + " from Flight f,Plane p "
                      + " where p.FlightID = f.FlightID and p.DepartureDate = @date and f.FromCity = @xFromCity   and f.ToCity = @xToCity and p.PlaneID not in ( "
                      + " select PlaneID from Plane where PlaneID = @planeID ) ";

                sc = new SqlCommand(query, DBContext.conn);
                sc.Parameters.AddWithValue("@date", date);
                sc.Parameters.AddWithValue("@xFromCity", xFromCity);
                sc.Parameters.AddWithValue("@xToCity", xToCity);
                sc.Parameters.AddWithValue("@planeID", xPlaneID);




                //SqlDataAdapter adapter = new SqlDataAdapter(query, DBContext.conn);

                SqlDataAdapter adapter = new SqlDataAdapter(sc);

                adapter.Fill(data);

                foreach (DataRow item in data.Rows)
                {
                    int flightID = Convert.ToInt16(item["FlightID"].ToString());
                    string fromCity = item["FromCity"].ToString();
                    string toCity = item["ToCity"].ToString();
                    float duration = float.Parse(item["Duration"].ToString());
                    string planeID = item["PlaneID"].ToString();
                    float fare = float.Parse(item["Fare"].ToString());
                    string xDepartureTime = item["DepartureTime"].ToString();
                    string xDepartureDate = item["DepartureDate"].ToString();
                    string departureTime = xDepartureTime.Replace("12:00:00 AM", "");
                    string departureDate = xDepartureDate.Replace("12:00:00 AM", "");
                    string arrives = "";

                    FlightPlane fp = new FlightPlane(flightID, fromCity, toCity, duration, planeID, fare, departureTime, departureDate, arrives);
                    list.Add(fp);


                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error:" + e.ToString());
            }
            finally
            {
                DBContext.conn.Close();
            }

            return list;
        }
    }
}