﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Client.Code.Controller
{
    public class WebPageBase: System.Web.UI.Page
    {
        protected override void OnInit(EventArgs e)
        {
            if (Session["email"] == null)
            {
                Response.Redirect("Login.aspx?toUrl=" + Request.Url.PathAndQuery);
            }
            base.OnInit(e);
        }
    }
}