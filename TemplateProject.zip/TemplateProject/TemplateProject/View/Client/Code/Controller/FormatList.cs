﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TemplateProject.View.Client.Code.Entities;

namespace TemplateProject.View.Client.Code.Controller
{
    public class FormatList
    {
        public FormatList() { }
        public static List<Bookings> FormatListBooking(List<Bookings> list)
        {
            foreach (Bookings b in list)
            {
                b.bookingTime = ConvertHours(b.bookingTime);
                b.departureTime = ConvertHours(b.departureTime);

                string temp = FormatHours(b.departureTime);
                string temp0 = temp.Replace(":", ".");

                float temp1 = float.Parse(temp0);
                float temp2 = temp1 + b.duration;

                if (temp2 <= 24)
                {
                    //   string temp3 = string.Format("{0}0", temp2);
                    string temp3 = Convert.ToString(temp2);
                    string temp4 = temp3.Replace(".", ":");

                    string temp5 = ConvertHours(temp4);
                    string arrives = b.departureDate + " (" + temp5 + ")";
                    b.arrives = arrives;


                }
                else
                {
                    float temp3 = temp2 - 24;
                    string temp4 = Convert.ToString(temp3);
                    string temp5 = temp4.Replace(".", ":");
                    string temp6 = ConvertHours(temp5);

                    string date = CounterDay(b.departureDate);
                    string arrives = date + " (" + temp6 + ")";
                    b.arrives = arrives;


                }

            }
            return list;
        }


        public static List<FlightPlane> FormatListFlight(List<FlightPlane> list)
        {
            foreach (FlightPlane b in list)
            {

                b.departTime = ConvertHours(b.departTime);

                string temp = FormatHours(b.departTime);
                string temp0 = temp.Replace(":", ".");

                float temp1 = float.Parse(temp0);
                float temp2 = temp1 + b.duration;

                if (temp2 <= 24)
                {
                    //   string temp3 = string.Format("{0}0", temp2);
                    string temp3 = Convert.ToString(temp2);
                    string temp4 = temp3.Replace(".", ":");

                    string temp5 = ConvertHours(temp4);
                    string arrives = b.departDate + " (" + temp5 + ")";
                    b.arrives = arrives;


                }
                else
                {
                    float temp3 = temp2 - 24;
                    string temp4 = Convert.ToString(temp3);
                    string temp5 = temp4.Replace(".", ":");
                    string temp6 = ConvertHours(temp5);

                    string date = CounterDay(b.departDate);
                    string arrives = date + " (" + temp6 + ")";
                    b.arrives = arrives;


                }

            }
            return list;
        }
        private static string CounterDay(string departureDate)
        {

            DateTime today = Convert.ToDateTime(departureDate);
            Console.WriteLine(today);
            DateTime answer = today.AddDays(1);
            string date = (answer.ToShortDateString()).ToString();

            return date;
        }

        private static string ConvertHours(string hours)
        {
            DateTime dateTime = Convert.ToDateTime(hours);
            string time = dateTime.ToString("hh:mm tt");

            return time;

        }

        private static string FormatHours(string hours)
        {
            DateTime dateTime = Convert.ToDateTime(hours);
            string time = dateTime.ToString("HH:mm");

            return time;

        }
        private static string CounterHours(float hours, string time)
        {
            DateTime today = Convert.ToDateTime(time);

            DateTime answer = today.AddDays(hours);
            string temp = (ConvertHours(answer.ToShortTimeString())).ToString();


            return temp;
        }
    }
}