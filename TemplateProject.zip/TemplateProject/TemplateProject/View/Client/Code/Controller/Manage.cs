﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Client.Code.Controller
{
    public class Manage
    {
        public Manage() { }
        public static string RandomReservationCode()
        {
            string strString = "abcdefghijklmnopqrstuvwxyz0123456789";
            Random random = new Random();
            int randomCharIndex = 0;
            char randomChar;
            string actcode = "";
            for (int i = 0; i < 6; i++)
            {
                randomCharIndex = random.Next(0, strString.Length);
                randomChar = strString[randomCharIndex];
                actcode += Convert.ToString(randomChar);
            }

            return actcode;
        }

        public static string GetDate(bool condition)
        {
            string date = "";
            string dayOfWeek = Convert.ToString(DateTime.Today.DayOfWeek);
            string day = Convert.ToString(DateTime.Now.Day);
            string month = Convert.ToString(DateTime.Now.Month);
            string year = Convert.ToString(DateTime.Now.Year);


            if (condition == true)
            {
                date = year + "-" + month + "-" + day;
            }
            else
            {
                date = dayOfWeek + " , " + year + "-" + month + "-" + day;
            }

            return date;
        }

        public static string GetTime()
        {
            string hours = Convert.ToString(DateTime.Now.Hour);
            string minute = Convert.ToString(DateTime.Now.Minute);
            string second = Convert.ToString(DateTime.Now.Second);

            string time = hours + ":" + minute + ":" + second;
            return time;
        }
    }
}