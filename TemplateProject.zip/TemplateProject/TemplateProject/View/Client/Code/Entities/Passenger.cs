﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Client.Code.Entities
{
    public class Passenger
    {
        public Passenger() { }
        public Passenger(string email, string password, string firstName, string lastName, string address, string sex, int phoneNumber, int age, int cardNumber)
        {
            this.email = email;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
            this.address = address;
            this.sex = sex;
            this.phoneNumber = phoneNumber;
            this.age = age;
            this.cardNumber = cardNumber;

        }

        public string email { get; set; }
        public string password { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string address { get; set; }
        public string sex { get; set; }
        public int phoneNumber { get; set; }
        public int age { get; set; }
        public int cardNumber { get; set; }
        public string Facebook { get; set; }
        public string Avatar { get; set; }
        public string BirthDate { get; set; }
        public bool IsAdmin { get; set; }
    }
}