﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Client.Code.Entities
{
    public class FlightPlane
    {
        public FlightPlane(int flightID, string fromCity, string toCity, float duration, string planeID, float fare, string departTime, string departDate, string arrives)
        {
            this.flightID = flightID;
            this.fromCity = fromCity;
            this.toCity = toCity;
            this.duration = duration;
            this.planeID = planeID;
            this.fare = fare;
            this.departTime = departTime;
            this.departDate = departDate;
            this.arrives = arrives;

        }

        public int flightID { get; set; }
        public string fromCity { get; set; }



        public string toCity { get; set; }
        public float duration { get; set; }
        public string planeID { get; set; }
        public float fare { get; set; }
        public string departTime { get; set; }
        public string departDate { get; set; }
        public string arrives { get; set; }

    }
}