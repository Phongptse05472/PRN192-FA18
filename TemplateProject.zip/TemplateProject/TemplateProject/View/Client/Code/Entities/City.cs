﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Client.Code.Entities
{
    public class City
    {
        public City(int cityID, string cityName)
        {
            this.cityID = cityID;
            this.cityName = cityName;
        }



        public int cityID { get; set; }
        public string cityName { get; set; }
    }
}