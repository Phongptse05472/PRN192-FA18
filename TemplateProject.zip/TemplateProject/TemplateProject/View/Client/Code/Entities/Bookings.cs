﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Client.Code.Entities
{
    public class Bookings
    {
        public Bookings() { }
        public string bookingID { get; set; }
        public string email { get; set; }
        public string planeID { get; set; }
        public string bookingDate { get; set; }
        public string bookingTime { get; set; }
        public string reservationCode { get; set; }
        public string fistName { get; set; }
        public string lastName { get; set; }
        public int flightID { get; set; }
        public float fare { get; set; }
        public string departureTime { get; set; }
        public string departureDate { get; set; }

        public string fromCity { get; set; }
        public string toCity { get; set; }
        public float duration { get; set; }
        public string arrives { get; set; }

        public Bookings(String planeID, String reservationCode)
        {


            this.planeID = planeID;

            this.reservationCode = reservationCode;
        }

        public Bookings(String email, String planeID, String bookingDate, String bookingTime, String reservationCode)
        {

            this.email = email;
            this.planeID = planeID;
            this.bookingDate = bookingDate;
            this.bookingTime = bookingTime;
            this.reservationCode = reservationCode;
        }
        public Bookings(String reservationCode, String email, String planeID, String bookingDate, String bookingTime, String fistName, String lastName, int flightID, float fare, String departureDate, String departureTime, String fromCity, String toCity, float duration)
        {
            this.reservationCode = reservationCode;
            this.email = email;
            this.planeID = planeID;
            this.bookingDate = bookingDate;
            this.bookingTime = bookingTime;
            this.fistName = fistName;
            this.lastName = lastName;
            this.flightID = flightID;
            this.fare = fare;
            this.departureDate = departureDate;
            this.departureTime = departureTime;
            this.fromCity = fromCity;
            this.toCity = toCity;
            this.duration = duration;

        }
    }
}