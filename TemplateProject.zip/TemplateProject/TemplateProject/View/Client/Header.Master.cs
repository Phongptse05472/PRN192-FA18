﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code.Data;
using TemplateProject.View.Client.Code.Entities;
using TemplateProject.View.Client.Code.Model;

namespace TemplateProject
{
    public partial class Header : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DateTime now = DateTime.Now;
                dateLabel.Text = now.ToString("yyyy-MM-dd");
                dateLabel.ForeColor = System.Drawing.Color.Red;
                InitLeftBar();
            }
        }
        public string GetActive()
        {
            string currentPage = System.IO.Path.GetFileNameWithoutExtension(HttpContext.Current.Request.Url.AbsolutePath).ToLower();
            if (currentPage.Equals("controller"))
            {
                currentPage = "managerbooking";
            }
            return currentPage;
        }

        private void InitLeftBar()
        {
            if (Session["email"] != null)
            {
                loginBtn.Visible = false;
                userImageControl.Visible = true;
                emailLinkButton.Visible = true;
                nameLabel.Visible = true;
                logoutBtn.Visible = true;
                Passenger passenger = new PassengerModel().getPassengerByEmail(Session["email"].ToString());
                userImageControl.ImageUrl = passenger.Avatar;
                emailLinkButton.Text = passenger.email;
                nameLabel.Text = passenger.lastName + " " + passenger.firstName;
            }
            else
            {
                loginBtn.Visible = true;
                userImageControl.Visible = false;
                emailLinkButton.Visible = false;
                nameLabel.Visible = false;
                logoutBtn.Visible = false;
            }
        }
        protected void logoutBtn_Click(object sender, EventArgs e)
        {
            if (Session["email"] != null) Session["email"] = null;
            Response.Redirect("Login.aspx");
        }

        protected void emailLinkButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("EditUser.aspx");
        }

        protected void logintBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}