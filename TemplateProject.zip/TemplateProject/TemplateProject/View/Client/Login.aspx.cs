﻿using ASPSnippets.FaceBookAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code.Data;
using TemplateProject.View.Admin.Code.Entity;

namespace TemplateProject.View.Client
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] != null)
            {
                Response.Redirect("Home.aspx");
            }
  
            LoadPage();
            string action = Request.QueryString["action"];
            if (action != null && action.Equals("loginfacebook"))
            {
                FaceBookConnect.Authorize("user_photos,email", Request.Url.AbsoluteUri.Split('?')[0]);
            }
            else
            {
                FacebookCall();
            }
        }
        private void LoadPage()
        {
            string error1 = Request.QueryString["error"];
            if (error1 != null)
            {
                error.Visible = true;
                error.Text = error1;
            }
        }
        protected void loginBtn_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string pass = txtPass.Text;
            Response.Redirect("Controller.aspx?action=login&email=" + email + "&pass=" + pass);
        }
        //========================================For facebook login =====================================================

        //Facebook Call Back
        void FacebookCall()
        {
            FaceBookConnect.API_Key = "181378172401625";
            FaceBookConnect.API_Secret = "458079d6569aae3a4b47cc323cc70906";
            if (Request.QueryString["error"] == "access_denied")
            {
                //ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('User has denied access.')", true);
                error.Visible = true;
                error.Text = "User has denied access !";
                return;
            }
            string code = Request.QueryString["code"];
            if (!string.IsNullOrEmpty(code))
            {
                string data = FaceBookConnect.Fetch(code, "me?fields=id,name,email");
                FaceBookUser faceBookUser = new JavaScriptSerializer().Deserialize<FaceBookUser>(data);
                Passenger pass = new Passenger();
                pass.Avatar = string.Format("https://graph.facebook.com/{0}/picture", faceBookUser.Id);
                pass.Email = faceBookUser.Email;
                pass.FirstName = faceBookUser.Name;
                pass.LastName = faceBookUser.UserName;
                User gotUser = new LoginContext().getUserEmailByEmail(pass.Email);
                if (gotUser!=null&& gotUser.UserName != null)
                {
                    Session["email"] = gotUser.UserName;
                    string toUrl = Request.QueryString["toUrl"];
                    if (string.IsNullOrEmpty(toUrl))
                    {
                        toUrl = "Home.aspx";
                    }
                    Response.Redirect(toUrl);
                }
                else
                {
                    new PassengerContext().AddPassengerFacebook(pass);
                    Session["email"] = pass.Email;
                    Response.Redirect("Home.aspx");
                }
            }
        }

        protected void registerBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/View/Admin/Login.aspx");
        }
    }

    //Store Facebook information
    public class FaceBookUser
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string PictureUrl { get; set; }
        public string Email { get; set; }
    }

}