﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TemplateProject.View.Client
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string error1 = Request.QueryString["error"];
            if (error1 != null)
            {
                messageLabel.Text = error1;
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            if (getEditData()) return;
            string email = txtEmail.Text;
            string pass = txtPass.Text;
            string verifyPass = txtVerify.Text;
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string address = txtLastName.Text;
            string phoneNumber = txtPhoneNumber.Text.ToString();
            string sex = dropSex.SelectedValue.ToString();
            int age = Convert.ToInt16(txtAge.Text);
            int cardNumber = Convert.ToInt16(txtCardNumber.Text);
            Response.Redirect("Controller.aspx?action=register&email=" + email + "&password=" + pass + "&firstName=" + firstName + "&lastName=" + lastName + "&address=" + address + "&sex=" + sex + "&phoneNumber=" + phoneNumber + "&age=" + age + "&cardNumber=" + cardNumber);
        }
        private bool getEditData()
        {

            bool isFail = false;
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                isFail = true;
                txtEmail.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtEmail.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtFirstName.Text))
            {
                isFail = true;
                txtFirstName.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtFirstName.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtLastName.Text))
            {
                isFail = true;
                txtLastName.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtLastName.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtPass.Text))
            {
                isFail = true;
                txtPass.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtPass.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtVerify.Text))
            {
                isFail = true;
                txtVerify.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtVerify.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtAddress.Text))
            {
                isFail = true;
                txtAddress.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtAddress.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtPhoneNumber.Text))
            {
                isFail = true;
                txtPhoneNumber.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtPhoneNumber.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtAge.Text))
            {
                isFail = true;
                txtAge.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtAge.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtCardNumber.Text))
            {
                isFail = true;
                txtCardNumber.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtCardNumber.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (!txtVerify.Text.Equals(txtPass.Text))
                if (isFail)
                {
                    messageLabel.Text = "Have some error, please check input again ( (*) is required and re-password must be match) !!!";
                    messageLabel.Visible = true;
                }
            return isFail;
        }
    }
}