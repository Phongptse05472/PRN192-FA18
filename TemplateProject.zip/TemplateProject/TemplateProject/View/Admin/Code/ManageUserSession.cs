﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using TemplateProject.View.Admin.Code.Entity;

namespace TemplateProject.View.Admin.Code
{
    public static class ManageUserSession
    {
        public static void setCurrrentUser(this HttpSessionState session, User user)
        {
            session["currentUser"] = user;
        }
        public static User getCurrentUser(this HttpSessionState session)
        {
            return session["currentUser"] as User;
        }
    }
}