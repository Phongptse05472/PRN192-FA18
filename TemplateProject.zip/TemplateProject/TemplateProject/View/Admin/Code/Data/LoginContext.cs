﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TemplateProject.View.Admin.Code.Entity;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace TemplateProject.View.Admin.Code.Data
{
    public class LoginContext
    {
        public string ConnectionString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString;

        public User getUserByUserNameAndPassword(User u)
        {
            string query = "select * from Passengers where Email=@username and Password=@password";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@username", u.UserName);
            cmd.Parameters.AddWithValue("@password", u.Password);
            SqlDataReader dr = cmd.ExecuteReader();
            User gotUser = new User();
            if (dr.Read())
            {
                gotUser.UserName = dr.GetString(dr.GetOrdinal("Email"));
                gotUser.IsAdmin = dr.GetBoolean(dr.GetOrdinal("IsAdmin"));
            }
            else
            {
                conn.Close();
                return null;
            }
            conn.Close();
            return gotUser;
        }
        public User getUserEmailByEmail(string email)
        {
            string query = "select * from Passengers where Email=@username";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@username", email);
            SqlDataReader dr = cmd.ExecuteReader();
            User gotUser = new User();
            if (dr.Read())
            {
                gotUser.UserName = dr.GetString(dr.GetOrdinal("Email"));
                gotUser.IsAdmin = dr.GetBoolean(dr.GetOrdinal("IsAdmin"));
            }
            else
            {
                conn.Close();
                return null;
            }
            conn.Close();
            return gotUser;
        }
    }
}
