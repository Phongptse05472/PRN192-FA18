﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using TemplateProject.View.Admin.Code.Entity;
namespace TemplateProject.View.Admin.Code.Data
{
    public class FlightContext
    {
        public string ConnectionString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString;
        public bool UpdateFlight(Flight flight)
        {
            string query = "update Flight set FromCity=@fromcity,ToCity=@tocity,Duration=@duration where FlightID =@flightid";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@flightid", flight.FlightID);
                cmd.Parameters.AddWithValue("@fromcity", flight.FromCityName);
                cmd.Parameters.AddWithValue("@tocity", flight.ToCityName);
                cmd.Parameters.AddWithValue("@duration", flight.Duration);
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool AddFlight(Flight flight)
        {
            if (isExistedFlight(flight.FromCityName, flight.ToCityName))
            {
                return false;
            }
            string query = "insert into Flight (FromCity,ToCity,Duration) values (@fromcity,@tocity,@duration)";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@fromcity", flight.FromCityName);
                cmd.Parameters.AddWithValue("@tocity", flight.ToCityName);
                cmd.Parameters.AddWithValue("@duration", flight.Duration);
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool DeleteFlightByFlightID(string flightid)
        {
            string query = "delete Flight where FlightID=@email";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@email", flightid);
                isSuccess = cmd.ExecuteNonQuery() != 0;
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public Flight getFlightByFlightID(string flightid)
        {
            string query = "select * from Flight where FlightID=@email";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@email", flightid);
            SqlDataReader dr = cmd.ExecuteReader();
            Flight flight = new Flight();
            SafeGetData safe = new SafeGetData();
            if (dr.Read())
            {
                flight.FlightID = safe.SafeGetInt(dr, "FlightID");
                flight.FromCityName = safe.SafeGetString(dr, "FromCity");
                flight.ToCityName = safe.SafeGetString(dr, "ToCity");
                flight.Duration = (float)safe.SafeGetDouble(dr, "Duration");
                conn.Close();
                return flight;
            }
            conn.Close();
            return null;
        }
        public DataSet getFlightByFlightID2(string flightid)
        {
            string query = "select * from Flight where FlightID=" + flightid;
            SqlDataAdapter da = new SqlDataAdapter(query, ConnectionString);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
       
        public DataSet SearchFlight(string fromcity, string tocity)
        {
            string query = "select * from Flight where FromCity like '%" + fromcity + "%' and ToCity like '%" + tocity + "%'";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnectionString);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public bool isExistedFlight(string fromcity, string tocity)
        {
            string query = "select * from Flight where FromCity like '%" + fromcity + "%' and ToCity like '%" + tocity + "%'";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                conn.Close();
                return true;
            }
            conn.Close(); return false;
        }
        //==============================================================================================//

    }
}