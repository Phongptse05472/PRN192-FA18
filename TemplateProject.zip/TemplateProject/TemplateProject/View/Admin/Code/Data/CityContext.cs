﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using TemplateProject.View.Admin.Code.Entity;

namespace TemplateProject.View.Admin.Code.Data
{
    public class CityContext
    {
        public string ConnectionString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString;

        public bool UpdateCity(City city)
        {
            string query = "update Cities set CityName=@cityname where CityID =@cityid";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@cityname", city.CityName);
                cmd.Parameters.AddWithValue("@cityid", city.CityID);
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool AddCity(string city)
        {
            string query = "insert into Cities (CityName) values (@cityname)";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@cityname", city);
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool DeleteCityByCityID(string cityID)
        {
            string query = "delete Cities where CityID=@cityid";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@cityid", cityID);
                isSuccess = cmd.ExecuteNonQuery() != 0;
            }
            catch
            {
                conn.Close();
            }
            return isSuccess;
        }
        public City getCityByCityID(string cityID)
        {
            string query = "select * from Cities where CityID=@cityid";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@cityid", cityID);
            SqlDataReader dr = cmd.ExecuteReader();
            City city = new City();
            SafeGetData safe = new SafeGetData();
            if (dr.Read())
            {
                city.CityID= safe.SafeGetInt(dr, "CityID");
                city.CityName = safe.SafeGetString(dr, "CityName");
                conn.Close();
                return city;
            }
            conn.Close();
            return null;
        }
        public DataSet SearchUser(string keyword)
        {
            string query = "select * from Cities where CityName like '%" + keyword + "%' or CityID like '%" + keyword + "%'";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnectionString);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }

        //==============================================================================================//

    }
}