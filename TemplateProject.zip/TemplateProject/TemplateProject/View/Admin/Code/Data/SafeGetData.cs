﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Admin.Code.Data
{
    /*
     * SafeGet null data from db
     * 
     */
    public class SafeGetData
    {
        public double SafeGetDouble(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetDouble(dr.GetOrdinal(colName));
            }
            return 0;
        }

        public string SafeGetString(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetString(dr.GetOrdinal(colName));
            }
            return null;
        }
        public int SafeGetInt(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetInt32(dr.GetOrdinal(colName));
            }
            return 0;
        }
        public bool SafeGetBool(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetBoolean(dr.GetOrdinal(colName));
            }
            return false;
        }
        public string SafeGetDatetime(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetDateTime(dr.GetOrdinal(colName)).ToString("yyyy-MM-dd");
            }
            return null;
        }
        public string SafeGetTime(SqlDataReader dr, string colName)
        {
            if (!dr.IsDBNull(dr.GetOrdinal(colName)))
            {
                return dr.GetTimeSpan(dr.GetOrdinal(colName)).ToString();
            }
            return null;
        }
    }
}