﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using TemplateProject.View.Admin.Code.Entity;
namespace TemplateProject.View.Admin.Code.Data
{
    public class PassengerContext
    {
        public string ConnectionString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString;

        public bool UpdatePassenger(Passenger passenger, bool youAreAdmin)
        {
            if (!youAreAdmin && !IsCorrectOldPassword(passenger.Email, passenger.OldPassword)) return false;
            string query = "update Passengers set FirstName=@firstName,LastName=@lastName,Password=@password,Address=@address,PhoneNumber=@phoneNumber," +
                            " Sex=@gender , Age=@age , CardNumber=@cardNumber ,Facebook=@facebook ,Avatar=@avatar , Birthdate=@birthDate where Email =@email";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@firstName", passenger.FirstName);
                cmd.Parameters.AddWithValue("@lastName", passenger.LastName);
                cmd.Parameters.AddWithValue("@password", passenger.Password);
                cmd.Parameters.AddWithValue("@address", passenger.Address);
                cmd.Parameters.AddWithValue("@phoneNumber", passenger.PhoneNumber);
                cmd.Parameters.AddWithValue("@gender", passenger.Gender);
                cmd.Parameters.AddWithValue("@age", passenger.Age);
                cmd.Parameters.AddWithValue("@cardNumber", passenger.CardNumber);
                cmd.Parameters.AddWithValue("@facebook", passenger.Facebook);
                cmd.Parameters.AddWithValue("@avatar", passenger.Avatar);
                cmd.Parameters.AddWithValue("@birthDate", passenger.BirthDate);
                cmd.Parameters.AddWithValue("@email", passenger.Email);
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool AddPassenger(Passenger passenger)
        {
            string query = "insert into Passengers (Email,Password,FirstName,LastName,Address,PhoneNumber,Sex,Age,CardNumber,Facebook,Avatar,Birthdate,IsAdmin) values (@email,@password,@firstName,@lastName,@address,@phoneNumber," +
                " @gender , @age , @cardNumber ,@facebook ,@avatar , @birthDate, @isad)";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@email", passenger.Email);
                cmd.Parameters.AddWithValue("@password", passenger.Password);
                cmd.Parameters.AddWithValue("@firstName", passenger.FirstName);
                cmd.Parameters.AddWithValue("@lastName", passenger.LastName);
                cmd.Parameters.AddWithValue("@address", passenger.Address);
                cmd.Parameters.AddWithValue("@phoneNumber", passenger.PhoneNumber);
                cmd.Parameters.AddWithValue("@gender", passenger.Gender);
                cmd.Parameters.AddWithValue("@age", passenger.Age);
                cmd.Parameters.AddWithValue("@cardNumber", passenger.CardNumber);
                cmd.Parameters.AddWithValue("@facebook", passenger.Facebook);
                cmd.Parameters.AddWithValue("@avatar", passenger.Avatar);
                cmd.Parameters.AddWithValue("@birthDate", passenger.BirthDate);
                cmd.Parameters.AddWithValue("@isad", "0");
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool AddPassengerFacebook(Passenger passenger)
        {
            //insert passenger into database
            string query = "insert into Passengers (Email,Password,FirstName,LastName,Avatar,IsAdmin) values (@email,@password,@firstName,@lastName,@avatar, @isad)";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@email", passenger.Email);
            cmd.Parameters.AddWithValue("@password", "30238423740237");
            cmd.Parameters.AddWithValue("@firstName", passenger.FirstName);
            cmd.Parameters.AddWithValue("@lastName", (passenger.LastName == null) ? "" : passenger.LastName);
            cmd.Parameters.AddWithValue("@avatar", passenger.Avatar);
            cmd.Parameters.AddWithValue("@isad", "0");
            bool isSuccess = cmd.ExecuteNonQuery() != 0;
            conn.Close();
            return isSuccess;
        }
        public bool DeletePassengerByEmail(string email)
        {
            string query = "delete Passengers where Email=@email";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@email", email);
            bool isSuccess = cmd.ExecuteNonQuery() != 0;
            conn.Close();
            return isSuccess;
        }
        private bool IsCorrectOldPassword(string email, string password)
        {
            string query = "select * from Passengers where Email=@username and Password=@password";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@username", email);
            cmd.Parameters.AddWithValue("@password", password);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                conn.Close();
                return true;
            }
            else return false;
        }
        public Passenger getPassengerByEmail(string email)
        {
            string query = "select * from Passengers where Email=@email";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@email", email);
            SqlDataReader dr = cmd.ExecuteReader();
            Passenger passenger = new Passenger();
            SafeGetData safe = new SafeGetData();
            if (dr.Read())
            {
                passenger.Email = safe.SafeGetString(dr, "Email");
                passenger.Password = safe.SafeGetString(dr, "Password");
                passenger.FirstName = safe.SafeGetString(dr, "FirstName");
                passenger.LastName = safe.SafeGetString(dr, "LastName");
                passenger.Address = safe.SafeGetString(dr, "Address");
                passenger.PhoneNumber = safe.SafeGetInt(dr, "PhoneNumber").ToString();
                passenger.Gender = safe.SafeGetBool(dr, "Sex");
                passenger.Age = safe.SafeGetInt(dr, "Age").ToString();
                passenger.CardNumber = safe.SafeGetInt(dr, "CardNumber").ToString();
                passenger.Facebook = safe.SafeGetString(dr, "Facebook");
                passenger.Avatar = safe.SafeGetString(dr, "Avatar");
                passenger.BirthDate = safe.SafeGetDatetime(dr, "Birthdate");
                conn.Close();
                return passenger;
            }
            conn.Close();
            return null;
        }
        public DataSet SearchUser(string keyword)
        {
            string query = "select * from Passengers where IsAdmin=0 AND (Email like '%" + keyword + "%' or FirstName like '%" + keyword + "%' or LastName like '%" + keyword + "%' or PhoneNumber like '%" + keyword + "%' or Facebook like '%" + keyword + "%')";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnectionString);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        //==============================================================================================//

    }
}