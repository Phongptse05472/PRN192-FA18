﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace TemplateProject.View.Admin.Code.Data
{
    /*
     *
     * use paging 
     * 
     */
    public class Paging
    {
        public string ConnectionString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString;

        public int getRowCount(string tableName)
        {
            string query = "select COUNT(*) from " + tableName;
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            int total = (int)cmd.ExecuteScalar();
            conn.Close();
            return total;
        }
        public DataSet getRowByPageNumber(int currentPage,string orderby,string tableName)
        {
            int pageSize = 5;
            int totalRow = getRowCount(tableName);
            int totalPage = totalRow / pageSize + 1;
            int fromRow = pageSize * (currentPage - 1) + 1;
            int toRow = pageSize * currentPage;

            string query = "with R as(select ROW_NUMBER() over(order by "+orderby+") 'rownumber', * from "+tableName+") " +
                            "select * from R where r.rownumber between " + fromRow + " and " + toRow;
            SqlDataAdapter da = new SqlDataAdapter(query, ConnectionString);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public DataSet getAllFromDB(string tableName)
        {
            string query = "select * from "+tableName;
            SqlDataAdapter da = new SqlDataAdapter(query, ConnectionString);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
    }
}