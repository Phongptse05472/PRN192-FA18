﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using TemplateProject.View.Admin.Code.Entity;
namespace TemplateProject.View.Admin.Code.Data
{
    public class PlaneContext
    {

        public string ConnectionString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString;

        public bool UpdatePlane(Plane plane)
        {
            string query = "update Plane set FlightID=@flightid,Fare=@fare,DepartureTime=@departuretime,DepartureDate=@departuredate where PlaneID =@planeid";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@flightid", plane.FlightID);
                cmd.Parameters.AddWithValue("@fare", plane.Fare);
                cmd.Parameters.AddWithValue("@departuretime", plane.DepartureTime);
                cmd.Parameters.AddWithValue("@departuredate", plane.DepartureDate);
                cmd.Parameters.AddWithValue("@planeid", plane.PlaneID);
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool AddPlane(Plane plane)
        {
            string query = "insert into Plane (PlaneID,FlightID,Fare,DepartureTime,DepartureDate) values (@planeid,@flightid,@fare,@departuretime,@departuredate)";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@flightid", plane.FlightID);
                cmd.Parameters.AddWithValue("@fare", plane.Fare);
                cmd.Parameters.AddWithValue("@departuretime", plane.DepartureTime);
                cmd.Parameters.AddWithValue("@departuredate", plane.DepartureDate);
                cmd.Parameters.AddWithValue("@planeid", plane.PlaneID);
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool DeletePlaneByID(string planeID)
        {
            string query = "delete Plane where PlaneID=@email";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            bool isSuccess = false;
            try
            {
                cmd.Parameters.AddWithValue("@email", planeID);
                isSuccess = cmd.ExecuteNonQuery() != 0;
                conn.Close();
            }
            catch (Exception)
            {
                conn.Close();
            }

            return isSuccess;
        }
        public Plane getPlaneByID(string planeID)
        {
            string query = "select * from Plane where PlaneID=@email";
            SqlConnection conn = new SqlConnection(ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@email", planeID);
            SqlDataReader dr = cmd.ExecuteReader();
            Plane plane = new Plane();
            SafeGetData safe = new SafeGetData();
            if (dr.Read())
            {
                plane.PlaneID = safe.SafeGetString(dr, "PlaneID");
                plane.FlightID = safe.SafeGetInt(dr, "FlightID");
                plane.Fare = (float)safe.SafeGetDouble(dr, "Fare");
                plane.DepartureTime = safe.SafeGetTime(dr, "DepartureTime");
                plane.DepartureDate = safe.SafeGetDatetime(dr, "DepartureDate");
                conn.Close();
                return plane;
            }
            conn.Close();
            return null;
        }
        public DataSet SearchPlane(string keyword)
        {
            string query = "select * from Plane where PlaneID like '%" + keyword + "%'";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnectionString);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        //==============================================================================================//


    }
}