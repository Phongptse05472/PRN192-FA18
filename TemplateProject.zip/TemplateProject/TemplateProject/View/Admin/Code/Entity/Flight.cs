﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Admin.Code.Entity
{
    public class Flight
    {
        public int FlightID { get; set; }
        public string FromCityName { get; set; }
        public string ToCityName { get; set; }
        public float Duration { get; set; }
    }
}