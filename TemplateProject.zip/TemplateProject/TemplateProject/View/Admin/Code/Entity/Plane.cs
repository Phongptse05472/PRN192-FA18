﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TemplateProject.View.Admin.Code.Entity
{
    public class Plane
    {
        public string PlaneID { get; set; }
        public int FlightID { get; set; }
        public float Fare { get; set; }
        public string DepartureTime { get; set; }
        public string DepartureDate { get; set; }
    }
}