﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using TemplateProject.View.Admin.Code;
using TemplateProject.View.Admin.Code.Data;

namespace TemplateProject.View.Admin
{
    public partial class CityManage : WebPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = new Paging().getAllFromDB("Cities").Tables[0];
                GridView1.DataBind();
                //============For first paging ================//
                int total = GridView1.Rows.Count;
                initPageList(total / 5 + 1);
                pageDropList.SelectedIndex = 1;
                pageDropList_SelectedIndexChanged(null, null);
                //=============================================//
            }
        }

        //================== Set value for DropdownList Paging =======================//
        private void initPageList(int total)
        {
            //DropDownList ddl = (DropDownList)GridView1.BottomPagerRow.Cells[0].FindControl("DropDownList1");
            pageDropList.Items.Add(new ListItem("All", "0"));
            for (int i = 1; i <= total; i++)
            {
                pageDropList.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }
        }
        //============================================================================//

        //=================================== Event handle ===========================================//
        protected void pageDropList_SelectedIndexChanged(object sender, EventArgs e)
        {
            int currentPage = int.Parse(pageDropList.SelectedValue.ToString());
            if (currentPage == 0)
            {
                bindDataToGridViewByDataset(new Paging().getAllFromDB("Cities"));
            }
            else
            {
                bindDataToGridViewByDataset(new Paging().getRowByPageNumber(currentPage,"CityName","Cities"));
            }
        }

        protected void firstBtn_Click(object sender, EventArgs e)
        {
            pageDropList.SelectedIndex = 1;
            pageDropList_SelectedIndexChanged(null, null);
        }

        protected void prevBtn_Click(object sender, EventArgs e)
        {
            int currentPage = int.Parse(pageDropList.SelectedValue.ToString());
            if (currentPage == 1) return;
            pageDropList.SelectedIndex = currentPage - 1;
            pageDropList_SelectedIndexChanged(null, null);
        }

        protected void nextBtn_Click(object sender, EventArgs e)
        {
            int currentPage = int.Parse(pageDropList.SelectedValue.ToString());
            int lastIndex = pageDropList.Items.Count - 1;
            if (currentPage == lastIndex) return;
            pageDropList.SelectedIndex = currentPage + 1;
            pageDropList_SelectedIndexChanged(null, null);
        }

        protected void lastBtn_Click(object sender, EventArgs e)
        {
            int lastIndex = pageDropList.Items.Count - 1;
            pageDropList.SelectedIndex = lastIndex;
            pageDropList_SelectedIndexChanged(null, null);
        }
        protected void searchBtn_Click(object sender, EventArgs e)
        {
            bindDataToGridViewByDataset(new CityContext().SearchUser(txtSearchBox.Text));
            pageDropList.SelectedIndex = 0;
        }

        protected void addBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddnewCity.aspx");
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow gvr = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            string cityID = gvr.Cells[0].Text;
            if (e.CommandName.Equals("EditCmd"))
            {
                Response.Redirect("EditCity.aspx?cityid=" + cityID);
            }
            else if (e.CommandName.Equals("DeleteCmd"))
            {
                string confirmValue = Request.Form["confirm_value"];
                if (confirmValue == "Yes")
                {
                    if (new CityContext().DeleteCityByCityID(cityID))
                    {
                        Response.Redirect("CityManage.aspx");
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Cannot delete this city !!!.')", true);
                    }
                }
            }
        }

        //===============================================================================================//

        //=========================== Bind data to gridview By Dataset ==========================//
        private void bindDataToGridViewByDataset(DataSet ds)
        {
            GridView1.DataSource =ds.Tables[0];
            GridView1.DataBind();
        }
        //===============================================================================================//


        //========================= Return a Dataset with changed gender attribute ======================//
        //private DataSet changeGender(DataSet ds)
        //{
        //    DataSet dsClone = ds.Clone();
        //    dsClone.Tables[0].Columns["Sex"].DataType = typeof(String);
        //    DataRowCollection drc = ds.Tables[0].Rows;
        //    DataRowCollection drcClone = dsClone.Tables[0].Rows;
        //    for (int i = 0; i < drc.Count; i++)
        //    {
        //        dsClone.Tables[0].ImportRow(ds.Tables[0].Rows[i]);
        //        string gender = drc[i]["Sex"].Equals(true) ? "Female" : "Male";
        //        drcClone[i]["Sex"] = gender;
        //    }
        //    return dsClone;
        //}

        //==============================================================================================//



        //protected void GridView1_DataBound(object sender, EventArgs e)
        //{
        //    DropDownList ddl = (DropDownList)GridView1.BottomPagerRow.Cells[0].FindControl("DropDownList1");
        //    for (int cnt = 0; cnt < GridView1.PageCount; cnt++)
        //    {
        //        int curr = cnt+1;
        //        ListItem item = new ListItem(curr.ToString());
        //        if (cnt == GridView1.PageIndex)
        //        {
        //            item.Selected = true;
        //        }
        //        ddl.Items.Add(item);
        //    }
        //    ListItem item1 = new ListItem("All");
        //    ddl.Items.Add(item1);
        //}
        //protected void ddlPaging_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    DropDownList ddl = (DropDownList)GridView1.BottomPagerRow.Cells[0].FindControl("DropDownList1");
        //    string query = "select * from PassengerTBL";
        //    SqlDataAdapter da = new SqlDataAdapter(query, ConnectionString);
        //    DataSet ds = new DataSet();
        //    da.Fill(ds);
        //    GridView1.DataSource = changeGender(ds).Tables[0];
        //    GridView1.PageIndex = ddl.SelectedIndex;
        //    GridView1.DataBind();
        //}
    }
}