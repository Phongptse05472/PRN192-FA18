﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code;
using TemplateProject.View.Admin.Code.Data;
using TemplateProject.View.Admin.Code.Entity;

namespace TemplateProject.View.Admin
{
    public partial class AddnewPlane : WebPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                loadDataToControl();
                flightDropdownlist_SelectedIndexChanged(null, null);
            }
        }

        //=================================== Check null for input, return Passenger if satify condition=====================================//
        private Plane getEditData()
        {
            Plane plane = new Plane();
            bool isFail = false;
            if (string.IsNullOrEmpty(txtFare.Text))
            {
                isFail = true;
                txtFare.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtFare.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtPlaneID.Text))
            {
                isFail = true;
                txtPlaneID.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtPlaneID.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtDepartureTime.Text))
            {
                isFail = true;
                txtDepartureTime.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtDepartureTime.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtDepartureDate.Text))
            {
                isFail = true;
                txtDepartureDate.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtDepartureDate.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (isFail)
            {
                messageLabel.Text = "Error, please !!!";
                messageLabel.Visible = true;
                return null;
            }
            plane.PlaneID = txtPlaneID.Text;
            plane.FlightID =int.Parse(flightDropdownlist.SelectedValue);
            plane.Fare = float.Parse(txtFare.Text);
            DateTime d = DateTime.Parse(txtDepartureTime.Text);
            plane.DepartureTime = d.ToString("HH:mm");
            plane.DepartureDate = txtDepartureDate.Text;
            return plane;
        }
        //===================================================================================================================================//


        //==================================================== Load data to control =========================================================//
        private void loadDataToControl()
        {
            txtFare.Attributes.Add("type", "number");
            flightDropdownlist.DataSource = new Paging().getAllFromDB("Flight").Tables[0];
            flightDropdownlist.DataTextField = "FlightID";
            flightDropdownlist.DataValueField = "FlightID";
            flightDropdownlist.DataBind();
        }

        protected void flightDropdownlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView1.DataSource = new FlightContext().getFlightByFlightID2(flightDropdownlist.SelectedValue).Tables[0];
            GridView1.DataBind();
        }

        protected void updateBtn_Click1(object sender, EventArgs e)
        {
            Plane plane = getEditData();
            if (plane == null) return;
            if (new PlaneContext().AddPlane(plane))
            {
                Response.Redirect("PlaneManage.aspx");
            }
            else
            {
                messageLabel.Visible = true;
                messageLabel.Text = "Cannot update !!!";
            }
        }


        //===================================================================================================================================//
    }
}