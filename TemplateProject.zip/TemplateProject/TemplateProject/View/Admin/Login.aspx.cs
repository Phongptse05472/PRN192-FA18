﻿using ASPSnippets.FaceBookAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code;
using TemplateProject.View.Admin.Code.Data;
using TemplateProject.View.Admin.Code.Entity;

namespace TemplateProject.View.Admin
{
    public partial class Login1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session.getCurrentUser() == null)
            {
                string action = Request.QueryString["action"];
                if (action != null && action.Equals("loginfacebook"))
                {
                    FaceBookConnect.Authorize("user_photos,email", Request.Url.AbsoluteUri.Split('?')[0]);
                }
                else
                {
                    FacebookCall();
                }
            }
            else
            {
                Response.Redirect("Home.aspx");
            }
        }

        protected void loginBtn_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.UserName = txtUserName.Text;
            user.Password = txtPassword.Text;
            user = new LoginContext().getUserByUserNameAndPassword(user);
            if (user != null && user.IsAdmin)
            {
                Session.setCurrrentUser(user);
                string toUrl = Request.QueryString["toUrl"];
                if (string.IsNullOrEmpty(toUrl))
                {
                    toUrl = "Home.aspx";
                }
                Response.Redirect(toUrl);
            }
            else if (user != null)
            {
                messageLoginLable.Visible = true;
                messageLoginLable.Text = "Your account don't have permession !";
            }
            else
            {
                messageLoginLable.Visible = true;
                messageLoginLable.Text = "User name or password is incorrect !";
            }
        }
        //========================================For facebook login =====================================================

        //Facebook Call Back
        void FacebookCall()
        {
            FaceBookConnect.API_Key = "181378172401625";
            FaceBookConnect.API_Secret = "458079d6569aae3a4b47cc323cc70906";
            if (Request.QueryString["error"] == "access_denied")
            {
                //ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('User has denied access.')", true);
                messageLoginLable.Visible = true;
                messageLoginLable.Text = "User has denied access !";
                return;
            }
            string code = Request.QueryString["code"];
            if (!string.IsNullOrEmpty(code))
            {
                string data = FaceBookConnect.Fetch(code, "me?fields=id,name,email");
                FaceBookUser faceBookUser = new JavaScriptSerializer().Deserialize<FaceBookUser>(data);
                faceBookUser.PictureUrl = string.Format("https://graph.facebook.com/{0}/picture", faceBookUser.Id);
                string email = faceBookUser.Email;
                User gotUser = new LoginContext().getUserEmailByEmail(email);
                if (gotUser.UserName != null && gotUser.IsAdmin)
                {
                    Session.setCurrrentUser(gotUser);
                    string toUrl = Request.QueryString["toUrl"];
                    if (string.IsNullOrEmpty(toUrl))
                    {
                        toUrl = "Home.aspx";
                    }
                    Response.Redirect(toUrl);
                }
                else
                {
                    messageLoginLable.Visible = true;
                    messageLoginLable.Text = "Your account don't have permission !";
                }
            }
        }
    }
    //Store Facebook information
    public class FaceBookUser
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string PictureUrl { get; set; }
        public string Email { get; set; }
    }
}