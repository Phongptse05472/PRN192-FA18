﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code;
using TemplateProject.View.Admin.Code.Data;
using TemplateProject.View.Admin.Code.Entity;

namespace TemplateProject
{
    public partial class HeaderPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DateTime now = DateTime.Now;
                dateLabel.Text = now.ToString("yyyy-MM-dd");
                dateLabel.ForeColor = System.Drawing.Color.Red;
                InitLeftBar();
            }
        }
        public string GetActive()
        {
            string currentPage = System.IO.Path.GetFileNameWithoutExtension(HttpContext.Current.Request.Url.AbsolutePath).ToLower();
            if (currentPage.Equals("edituser")|| currentPage.Equals("addnewuser"))
            {
                currentPage = "usermanage";
            }else if(currentPage.Equals("addnewcity")|| currentPage.Equals("editcity"))
            {
                currentPage = "citymanage";
            }else if (currentPage.Equals("addnewplane") || currentPage.Equals("editplane"))
            {
                currentPage = "planemanage";
            }
            else if (currentPage.Equals("editflight") || currentPage.Equals("addnewflight"))
            {
                currentPage = "flightmanage";
            }
            return currentPage;
        }

        private void InitLeftBar()
        {
            if (Session.getCurrentUser() != null)
            {
                Passenger passenger = new PassengerContext().getPassengerByEmail(Session.getCurrentUser().UserName);
                userImageControl.ImageUrl = passenger.Avatar;
                emailLinkButton.Text = passenger.Email;
                nameLabel.Text = passenger.LastName + " " + passenger.FirstName;
            }
        }
        protected void logoutBtn_Click(object sender, EventArgs e)
        {
            if (Session.getCurrentUser() != null) Session.setCurrrentUser(null);
            Response.Redirect("Login.aspx");
        }

        protected void emailLinkButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("EditUser.aspx?email=" + emailLinkButton.Text);
        }

  
    }
}