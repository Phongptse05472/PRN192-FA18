﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code;
namespace TemplateProject.View.Admin
{
    public partial class Home : WebPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}