﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code;
using TemplateProject.View.Admin.Code.Data;
using TemplateProject.View.Admin.Code.Entity;

namespace TemplateProject
{
    public partial class HeaderPageForLogin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
            }
        }
    }
}