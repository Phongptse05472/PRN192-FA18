﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code.Data;
using TemplateProject.View.Admin.Code.Entity;

namespace TemplateProject.View.Admin
{
    public partial class EditCity : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string cityID = Request.QueryString["cityid"];
                if (cityID != null)
                {
                    cityLabel.Text = cityID;
                    txtCityName.Text = new CityContext().getCityByCityID(cityID).CityName;
                }
                else
                {
                    Response.Redirect("CityManage.aspx");
                }
            }
        }
        protected void addBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCityName.Text))
            {
                messsageLabel.Visible = true;
                messsageLabel.Text = "City name cannot be empty !";
                return;
            }
            City c = new City();
            c.CityID = int.Parse(cityLabel.Text);
            c.CityName = txtCityName.Text;
            if (new CityContext().UpdateCity(c))
            {
                Response.Redirect("CityManage.aspx");
            }
            else
            {
                messsageLabel.Visible = true;
                messsageLabel.Text = "Error, cannot edit city!";
            }
        }
    }
}