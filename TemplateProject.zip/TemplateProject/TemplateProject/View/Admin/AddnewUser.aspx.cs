﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code;
using TemplateProject.View.Admin.Code.Data;
using TemplateProject.View.Admin.Code.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
namespace TemplateProject.View.Admin
{
    public partial class AddUser : WebPageBase
    {
        public string ConnectionString = WebConfigurationManager.ConnectionStrings["AirLinesConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                genderDropList.Items.Add(new ListItem("Male", "0"));
                genderDropList.Items.Add(new ListItem("FeMale", "1"));
                txtPhoneNumber.Attributes.Add("Type", "number");
                txtAge.Attributes.Add("Type", "number");
                txtCardNumber.Attributes.Add("Type", "number");
            }
        }

        protected void cancelBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserMange.aspx");
        }

        protected void updateBtn_Click(object sender, EventArgs e)
        {
            Passenger passenger = getEditData();
            if (passenger == null) return;
            if (imageUpload.HasFile)
            {
                passenger.Avatar = SaveFile(imageUpload.PostedFile, passenger.Email);
            }
            else
            {
                passenger.Avatar = "Resources/images/PassengerAvatar/DefaultAvatar.png";
            }
            if (new PassengerContext().AddPassenger(passenger))
            {
                Response.Redirect("UserManage.aspx");
            }
        }
        private Passenger getEditData()
        {
            Passenger passenger = new Passenger();
            bool isFail = false;
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                isFail = true;
                txtEmail.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtEmail.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtFirstName.Text))
            {
                isFail = true;
                txtFirstName.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtFirstName.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtLastName.Text))
            {
                isFail = true;
                txtLastName.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtLastName.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                isFail = true;
                txtPassword.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtPassword.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtAddress.Text))
            {
                isFail = true;
                txtAddress.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtAddress.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtPhoneNumber.Text))
            {
                isFail = true;
                txtPhoneNumber.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtPhoneNumber.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtAge.Text))
            {
                isFail = true;
                txtAge.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtAge.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (string.IsNullOrEmpty(txtCardNumber.Text))
            {
                isFail = true;
                txtCardNumber.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtCardNumber.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (isFail)
            {
                messageLabel.Text = "Error, please !!!";
                messageLabel.Visible = true;
                return null;
            }
            passenger.Email = txtEmail.Text;
            passenger.FirstName = txtFirstName.Text;
            passenger.LastName = txtLastName.Text;
            passenger.Password = txtPassword.Text;
            passenger.Address = txtAddress.Text;
            passenger.PhoneNumber = txtPhoneNumber.Text;
            passenger.Gender = (genderDropList.SelectedIndex == 1) ? true : false;
            passenger.Age = txtAge.Text;
            passenger.CardNumber = txtCardNumber.Text;
            passenger.Facebook = txtFacebook.Text;
            passenger.BirthDate = txtBirthDate.Text;
            return passenger;
        }

        private string SaveFile(HttpPostedFile file, string email)
        {
            // Specify the path to save the uploaded file to.
            string savePath = Server.MapPath("~/View/Admin/Resources/images/PassengerAvatar/");
            // Get the name of the file to upload.
            string fileName = email + "Avatar" + imageUpload.FileName.Substring(imageUpload.FileName.LastIndexOf("."));
            // Append the name of the file to upload to the path.
            savePath += fileName;

            // Call the SaveAs method to save the uploaded
            // file to the specified directory.
            imageUpload.SaveAs(savePath);
            return "Resources/images/PassengerAvatar/"+fileName;
            //// Create the path and file name to check for duplicates.
            //string pathToCheck = savePath + fileName;

            //// Create a temporary file name to use for checking duplicates.
            //string tempfileName = "";

            //// Check to see if a file already exists with the
            //// same name as the file to upload.        
            //if (System.IO.File.Exists(pathToCheck))
            //{
            //    int counter = 2;
            //    while (System.IO.File.Exists(pathToCheck))
            //    {
            //        // if a file with this name already exists,
            //        // prefix the filename with a number.
            //        tempfileName = counter.ToString() + fileName;
            //        pathToCheck = savePath + tempfileName;
            //        counter++;
            //    }

            //    fileName = tempfileName;

            //    // Notify the user that the file name was changed.
            //    messageLabel.Text = "A file with the same name already exists." +
            //        "<br />Your file was saved as " + fileName;
            //}
            //else
            //{
            //    // Notify the user that the file was saved successfully.
            //    messageLabel.Text = "Your file was uploaded successfully.";
            //}
        }
    }
}