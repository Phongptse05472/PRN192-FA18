﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code.Entity;
using TemplateProject.View.Admin.Code.Data;

namespace TemplateProject.View.Admin
{
    public partial class AddnewFlight : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                loadDataToControl();
            }
        }
        private Flight getEditData()
        {
            Flight flight = new Flight();
            bool isFail = false;
            if (string.IsNullOrEmpty(txtDuration.Text))
            {
                isFail = true;
                txtDuration.BackColor = System.Drawing.Color.FromArgb(255, 204, 204);
            }
            else
            {
                txtDuration.BackColor = System.Drawing.Color.FromArgb(232, 238, 239);
            }
            if (fromCityDroplist.SelectedItem.Text.Equals(toCityDroplist.SelectedItem.Text))
            {
                isFail = true;
            }
            if (isFail)
            {
                messageLabel.Text = "Error, please check again!!!";
                messageLabel.Visible = true;
                return null;
            }
            flight.FromCityName = fromCityDroplist.SelectedItem.Text;
            flight.ToCityName = toCityDroplist.SelectedItem.Text;
            flight.Duration = float.Parse(txtDuration.Text);
            return flight;
        }
        //===================================================================================================================================//


        //==================================================== Load data to control =========================================================//
        private void loadDataToControl()
        {
            txtDuration.Attributes.Add("type", "number");
            fromCityDroplist.DataSource = new Paging().getAllFromDB("Cities").Tables[0];
            fromCityDroplist.DataTextField = "CityName";
            fromCityDroplist.DataValueField = "CityName";
            fromCityDroplist.DataBind();
            toCityDroplist.DataSource = new Paging().getAllFromDB("Cities").Tables[0];
            toCityDroplist.DataTextField = "CityName";
            toCityDroplist.DataValueField = "CityName";
            toCityDroplist.DataBind();
        }

        protected void updateBtn_Click(object sender, EventArgs e)
        {
            Flight flight = getEditData();
            if (flight == null) return;
            if (new FlightContext().AddFlight(flight))
            {
                Response.Redirect("FlightManage.aspx");
            }
            else
            {
                messageLabel.Visible = true;
                messageLabel.Text = "Cannot update !!!";
            }
        }
    }
}
