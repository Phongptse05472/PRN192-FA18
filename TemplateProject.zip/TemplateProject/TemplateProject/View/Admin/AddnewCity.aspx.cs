﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TemplateProject.View.Admin.Code;
using TemplateProject.View.Admin.Code.Data;

namespace TemplateProject.View.Admin
{
    public partial class AddnewCity : WebPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void addBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCityName.Text))
            {
                messsageLabel.Visible = true;
                messsageLabel.Text = "City name cannot be empty !";
                return;
            }
            if(new CityContext().AddCity(txtCityName.Text))
            {
                Response.Redirect("CityManage.aspx");
            }
            else
            {
                messsageLabel.Visible = true;
                messsageLabel.Text = "Error, cannot add city (duplicate city) !";
            }
        }
    }
}